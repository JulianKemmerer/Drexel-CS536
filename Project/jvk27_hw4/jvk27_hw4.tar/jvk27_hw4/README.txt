Regarding the (very) late submission:
I apologize for the late submission. I was attending a conference in 
San Francisco (DAC 2014) for most of last week and part of this week.
Hopefully you can be lenient with late point deductions for that reason. 
If you require proof of this, I can certainly provide anything you need.
Thanks!
Julian

Program Features: All features from HW4
Language: Python
OS: Linux (Tux)
Compiler: None
Name of file containing main(): CG_hw4
How to compile: N/A (No makefile)
(Let me know if you need a make file for your scripts, I don't provide
one as it wouldn't really do anything)
How to run: ./CG_hw4 -h
