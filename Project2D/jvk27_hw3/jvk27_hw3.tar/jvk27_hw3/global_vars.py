#!/usr/bin/env python

#Command line option defaults
ps_file = "hw3_split.ps" #f
scale = 1.0 #s
rotation_cc = 0 #r #Counter clockwise
trans_x = 0 #m
trans_y = 0 #n
lower_bound_x = 0 #a
lower_bound_y = 0 #b
upper_bound_x = 250 #c
upper_bound_y = 250 #d
#Viewport
vp_lower_bound_x = 0 #j
vp_lower_bound_y = 0 #k
vp_upper_bound_x = 200 #o
vp_upper_bound_y = 200 #p
#Output image size
img_res_x = 501
img_res_y = 501
#Broken floating point to integer conversion bug
use_broken_fp = False
