Program Features: All commandline options from the assignment description are supported.
Language: C
OS: Linux (Tux)
Compiler: gcc
Name of file containing main(): main.c
How to compile: gcc *.c -o CG_hw1 -lm
