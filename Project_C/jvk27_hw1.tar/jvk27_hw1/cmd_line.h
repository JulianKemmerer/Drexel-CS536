#ifndef CMD_LINE_H
#define CMD_LINE_H

//Do commandline parsing directly into global variables
void do_cmd_line_parse(int argc, char** argv);

#endif
