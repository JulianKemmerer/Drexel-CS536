#ifndef XPM_H
#define XPM_H

void do_xpm_write(struct Matrix2D pixel_map);

#endif
